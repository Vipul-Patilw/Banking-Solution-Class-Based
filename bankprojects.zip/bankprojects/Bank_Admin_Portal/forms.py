from Bank_Admin_Portal.registration_form.userlogin import UserCreateForm
from Bank_Admin_Portal.userscreation_form.usercaccount import UserAccountCreateForm
from django import forms
from Bank_Admin_Portal.models import MatchSignature



UserCreateForm
UserAccountCreateForm 

class MatchSingatureForm(forms.ModelForm):
    class Meta:
        model = MatchSignature
        fields = ["signature_image"]
        widgets = {
            'signature_image':forms.FileInput(attrs={'id':"signature" , 'onchange':"loadSignature(event)",'style':'display:none'})}
    			    
