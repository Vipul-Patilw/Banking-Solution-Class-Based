from django.contrib import admin

# Register your models here.
from Bank_Admin_Portal.models import Users_Account,MatchSignature
# Register your models here.
admin.site.register(Users_Account)
admin.site.register(MatchSignature)