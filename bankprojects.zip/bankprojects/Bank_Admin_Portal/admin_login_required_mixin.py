from django.contrib import messages
from django.shortcuts import redirect
from django.contrib.auth.mixins import LoginRequiredMixin
class AdminLoginRequiredMixin(LoginRequiredMixin):
	def dispatch(self, request, *args, **kwargs):
	           if not request.user.is_authenticated:
	           	messages.error(request,"Please logged in to access pages")
	           	return redirect ("adminlogin")
	           if not request.user.is_staff:
	           	messages.error(request,"You're not authorised to access any page, Please try login using admin or staff account")
	           	return redirect('adminlogin')
	           return super(AdminLoginRequiredMixin, self).dispatch(
            request, *args, **kwargs
        )