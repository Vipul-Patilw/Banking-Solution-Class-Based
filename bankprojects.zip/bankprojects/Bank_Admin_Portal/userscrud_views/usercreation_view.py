from django.urls import reverse_lazy
from Bank_Admin_Portal.models import Users_Account
from django.views.generic.edit import CreateView,UpdateView
from Bank_Admin_Portal.forms import UserAccountCreateForm
from Bank_Admin_Portal.admin_login_required_mixin import AdminLoginRequiredMixin
class UserAccountCreate(AdminLoginRequiredMixin,CreateView):

		model = Users_Account
		template_name = 'users_account.html'
		form_class = UserAccountCreateForm	
		success_url = reverse_lazy('adminhome')