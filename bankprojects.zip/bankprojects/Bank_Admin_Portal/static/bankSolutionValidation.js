
  window.onload = function() {
  var show = localStorage.getItem('show');
  let account_number = document.getElementById("validationCustom01").value;
  if(show === 'true' && account_number != ""){
  let element = document.getElementById("both")
   element.classList.remove("mystyle");
  }
  }
  
 
  
  var cvv = document.getElementById("validationCustom05");
  
  cvv.onkeydown = function () {
  cvv.maxLength="3"}
  // var input = document.getElementById("validationCustom01");
  
  // input.onkeydown = function () {
  //     if (input.value.length > 0) {
  
  //         if (input.value.length % 4 == 0) {
  //         if(input.value.length < 16){
  //             input.value += " ";}
  //         }
  //     }
  
  // }
  var c_num = document.getElementById("validationCustom02");
  
  c_num.onkeydown = function () {
  if (c_num.value.length > 0 ) {
  
  if (c_num.value.length == 4 ) {
  
  c_num.value += " ";
  }
  if (c_num.value.length == 9 ) {
  
  c_num.value += " ";
  }
  if (c_num.value.length == 14 ) {
  
  c_num.value += " ";
  }
  }
  
  }
  
  var e_date = document.getElementById("validationCustom04");
  
  e_date.onkeydown = function () {
  e_date.maxLength ="5"
  if (e_date.value.length > 0 ) {
  
  if (e_date.value.length  == 2) {
  
  e_date.value += "/";
  }
  }
  
  }
  
  var element = document.getElementById("both")
  var data = document.getElementById("submit") 
  data.addEventListener("click",()=>{
  element.classList.remove("mystyle");
  })
  
  function account_number_validation() {
  var y = document.getElementById("validationCustom01").value;
  document.getElementById("validationCustom01").maxLength="12"
  if(y.length==0){
  document.getElementById("a_error").innerHTML="";
  }
  else if(y.length != 12){
  document.getElementById("a_error").innerHTML = "please enter a valid account number";
  
  }
  else{
  var element = document.getElementById("both")
  element.classList.remove("mystyle");
  document.getElementById("a_error").innerHTML="";
  localStorage.setItem('show', 'true');
  
  }
  }
  function card_number_validation() {
  var z = document.getElementById("validationCustom02").value;
  document.getElementById("validationCustom02").maxLength="19";
  
  if(z.length==0){
  document.getElementById("c_error").innerHTML="";
  }
  else if(z.length != 19){
  document.getElementById("c_error").innerHTML = "please enter a valid card number";
  
  }
  else{
  
  document.getElementById("c_error").innerHTML="" 
  }
  }
  // Example starter JavaScript for disabling form submissions if there are invalid fields
  (function () {
  'use strict'
  
  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')
  
  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
  .forEach(function (form) {
  form.addEventListener('submit', function (event) {
  if (!form.checkValidity()) {
  event.preventDefault()
  event.stopPropagation()
  }
  
  form.classList.add('was-validated')
  }, false)
  })
  })()
  var Anum = document.querySelector('#validationCustom01');
  
  Anum.addEventListener('input', restrictNumber);
  function restrictNumber (e) {  
  var newValue = this.value.replace(new RegExp(/[^\d\s]/,'ig'), "");
  this.value = newValue;
  }
  
  var Cnum = document.querySelector('#validationCustom02');
  
  Cnum.addEventListener('input', restrictNumber);
  function restrictNumber2 (e) {  
  var newValue = this.value.replace(new RegExp(/[^\d\s]/,'ig'), "");
  this.value = newValue;
  }
  