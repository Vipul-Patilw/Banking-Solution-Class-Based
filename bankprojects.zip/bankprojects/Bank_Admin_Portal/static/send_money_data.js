var amounts = document.getElementById("amount");

var confirm_account_number = document.getElementById("confirm_account_number");
var account_number = document.getElementById("account_number");
let users = document.getElementById("users");
let input_holder_name = document.getElementById("holder_name");
account_number.onkeyup = function () {

let all_users = JSON.parse(users.value);
let user_detail = confirm_account_number.value;
let data_user = all_users[user_detail];
if(data_user && user_detail==account_number.value){
      input_holder_name.value = data_user[0];
      document.getElementById("profile").innerHTML = "<img src='../media/"+ data_user[1]+"' class='rounded-circle' height='25' width='25' alt='profile' loading='lazy'>";  
      document.getElementById("account_error").innerHTML="";
} 
else if (user_detail==""){
document.getElementById("account_error").innerHTML="";
}
else {
document.getElementById("account_error").innerHTML="This account number does not match with above account number.";
input_holder_name.value="";
document.getElementById("profile").innerHTML="<i class='fas fa-user all_icons holder_icon'></i>"
}

}
confirm_account_number.onkeyup = function () {


let all_users = JSON.parse(users.value);
let user_detail = confirm_account_number.value;
let data_user = all_users[user_detail];
if(data_user && user_detail==account_number.value){
      input_holder_name.value = data_user[0];
      document.getElementById("profile").innerHTML = "<img src='../media/"+ data_user[1]+"' class='rounded-circle' height='25' width='25' alt='profile' loading='lazy'>";  
      document.getElementById("account_error").innerHTML="";
} 
else if (user_detail==""){
document.getElementById("account_error").innerHTML="";
}
else {
document.getElementById("account_error").innerHTML="This account number does not match with above account number.";
input_holder_name.value="";
document.getElementById("profile").innerHTML="<i class='fas fa-user all_icons holder_icon'></i>"
}

}
      
 amounts.onkeyup = function () {
 if(amounts.value ==""){
 document.getElementById("amount_error").innerHTML = "";  
 }
 else if (amounts.value < 1 ){
 document.getElementById("amount_error").innerHTML = "Please enter an valid amount ";}
 
 else{
 document.getElementById("amount_error").innerHTML = "";
 } 
 }