var csrftoken = Cookies.get('csrftoken');
function csrfSafeMethod(method) {
  // these HTTP methods do not require CSRF protection
  return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}
$.ajaxSetup({
  beforeSend: function(xhr, settings) {
    if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
      xhr.setRequestHeader("X-CSRFToken", csrftoken);
    }
  }
});

$(document).ready(function(){
  var page = 1;
  var empty_page = false;
  var block_request = false;
  var num_pages=parseInt('{{ page_obj.paginator.num_pages }}')
  $(window).scroll(function() {
 
      if  ($(window).scrollTop() && empty_page == false &&
      block_request == false) {
      block_request = true;
      page += 1;
   
      if(num_pages-page >= 0) {
      $(".fa-sync").addClass('fa-spin');
      $.get('?page=' + page, function(data) {
          block_request = false;

          console.log(data)
          $('#users_data').append(data);
          }
      );
      }
      else{
    
      $("#loadmore").html("No More Data");}}
  });
});