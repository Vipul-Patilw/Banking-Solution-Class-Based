let holder_name = document.getElementById("holder_name");
  
  holder_name.onkeyup = function () {

  holder_name.value = holder_name.value.toUpperCase();
  }
  holder_name.onkeydown = function () {
  const re = /^(?:\S*\s){2}/;

  if (re.test(holder_name.value) || holder_name.value == ""){
    document.getElementById("h_error").innerHTML = "";
  }
else{
  document.getElementById("h_error").innerHTML = "please enter your full name";
}}


  let element_data = document.getElementById("both")
  let data_submit = document.getElementById("submit") 
  data_submit.addEventListener("click",()=>{
    element_data.classList.remove("mystyle");
  })


  let loadProfile = function(event) {
  let image = document.getElementById('profile_output');
//   var files = document.getElementById('file'); 
  image.src = URL.createObjectURL(event.target.files[0]);
  };

  let loadSgnature = function(event) {
    

  let imageSignature = document.getElementById('signature_output');

//   var files = document.getElementById('file'); 
  imageSignature.src = URL.createObjectURL(event.target.files[0]);
  };


  let cvv2 = document.getElementById("cvv");
  
  cvv2.onkeydown = function () {
  cvv2.maxLength="3"}

let cd_num = document.getElementById("c_num");

cd_num.onkeydown = function () {
       if (cd_num.value.length > 0 ) {

        if (cd_num.value.length == 4 ) {
        
        cd_num.value += " ";
        }
           if (cd_num.value.length == 9 ) {
        
        cd_num.value += " ";
        }
           if (cd_num.value.length == 14 ) {
        
        cd_num.value += " ";
        }
    }
    
}
     
   let ex_date = document.getElementById("e_date");
   
   ex_date.onkeydown = function () {
   ex_date.maxLength ="5"
   if (ex_date.value.length > 0 ) {
   
   if (ex_date.value.length  == 2) {
  
   ex_date.value += "/";
   }
   }
   
   }



  function phoneValidation() {
  var x = document.getElementById("phone").value;
  if(x.length==0){
  document.getElementById("m_error").innerHTML="";
  }
  else if(x.length != 10){
  
  document.getElementById("m_error").innerHTML = "please enter a valid 10 digit number";
  
  }
  
  else{
  document.getElementById("m_error").innerHTML="";
  }
  }
  function account_number_validation() {
  let y = document.getElementById("a_num").value;
  document.getElementById("a_num").maxLength="12"
  if(y.length==0){
  document.getElementById("a_error").innerHTML="";
  }
  else if(y.length != 12){
  document.getElementById("a_error").innerHTML = "please enter a valid account number";
  
  
  }
  else{
  document.getElementById("a_error").innerHTML="";
  
  }
  }
  function card_number_validation() {
  let z = document.getElementById("c_num").value;
  document.getElementById("c_num").maxLength="19";
  
  if(z.length==0){
  document.getElementById("c_error").innerHTML="";
  }
  else if(z.length != 19){
  document.getElementById("c_error").innerHTML = "please enter a valid card number";
  
  }
  else{
  let element = document.getElementById("both")
  element.classList.remove("mystyle");
  document.getElementById("c_error").innerHTML="" 
  }
  }
  
  