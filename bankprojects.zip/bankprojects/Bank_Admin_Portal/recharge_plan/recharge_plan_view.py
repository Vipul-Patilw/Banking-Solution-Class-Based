from django.views.generic.edit import CreateView,UpdateView,DeleteView
from django.views.generic import ListView,DetailView
from Bank_Admin_Portal.models import RechargePlan
from Bank_Admin_Portal.forms import RechargePlanForm
from Bank_Admin_Portal.admin_login_required_mixin import AdminLoginRequiredMixin
from django.urls import reverse_lazy

class RechargePlanView(AdminLoginRequiredMixin,CreateView):
	form_class = RechargePlanForm
	template_name = 'recharge_plan_form.html'
	success_url = 'recharge_plan_list'
	
class RechargePlanList(AdminLoginRequiredMixin,ListView):
	model = RechargePlan
	template_name = 'recharge_plan_list.html'
	context_object_name = 'recharge_list'
	ordering = ['-add_update_date']
	paginate_by = 10
	
class RechargePlanUpdate(AdminLoginRequiredMixin,UpdateView,DetailView):
	model = RechargePlan
	template_name = 'recharge_plan_form.html'
	context_object_name = 'recharge_detail'
	form_class = RechargePlanForm
	success_url = reverse_lazy('recharge_plan_list')
	
class RechagePlanDelete(AdminLoginRequiredMixin,DeleteView):
	model = RechargePlan
	template_name = 'recharge_plan_delete.html'
	success_url = reverse_lazy('recharge_plan_list')
	