from django.shortcuts import render,HttpResponse
from Bank_Admin_Portal.userscreation_view.usercreation_view import UserAccountCreate
from Bank_Admin_Portal.usersdetail_view.usersdetail import  UsersDetail
from django.views.generic.edit import CreateView
from django.views.generic import TemplateView
from Bank_Admin_Portal.forms import MatchSingatureForm
#from Bank_Admin_Portal.models import MatchSignature
#from sentence_transformers import SentenceTransformer, util
from PIL import Image
import glob
import os
from django.core.exceptions import ValidationError

UserAccountCreate

UsersDetail

# Create your views here.


class MatchSignatureView(CreateView):
    template_name = "scan_signature.html"
    form_class = MatchSingatureForm
    success_url="signature_matched_user"
    def form_valid(self,form):
        signature_image = form.cleaned_data['signature_image']
        # print('Loading CLIP Model...')
     #   model = SentenceTransformer('clip-ViT-B-32')

#        image_names = list(glob.glob('..//media//Admin_Portal//signatures//*.jpg'))
#        outside_image = '..//media//Admin_Portal//match_signatures//'+str(signature_image)
#        image_names.append(outside_image)

#        # print("Images:", len(image_names))
#        encoded_image = model.encode([Image.open(filepath) for filepath in image_names], batch_size=128, convert_to_tensor=True, show_progress_bar=True)

#        processed_images = util.paraphrase_mining_embeddings(encoded_image)
#        NUM_SIMILAR_IMAGES = 10
#        print('Finding near duplicate images...')

#        threshold = 0.99
#        near_duplicates = [image for image in processed_images if image[0] < threshold]
#        for score, image_id1, image_id2 in near_duplicates[0:NUM_SIMILAR_IMAGES]:
#            scores = score * 100
#            if scores > 85:
#                print("signature matched")
#                print("\nScore: {:.2f}%".format(score * 100))
#                print(image_names[image_id1])
#                print(image_names[image_id2])

#            else:
#                raise ValidationError({'signature_image':"This Signature dosen't matched with  any account holder records"})



# class SignatureMatchingUser(TemplateView):
#     template_name = 'signature_matching_user.html'
    
#     def get_context_data(self, *args,**kwargs):
#         context = super(SignatureMatchingUser, self).get_context_data(*args,**kwargs)
#         sign_img =  f"Admin_Portal/match_signatures/{kwargs['signature_image']}"
#         sign = MatchSignature.objects.get(signature_image=sign_img)
#         context = sign 
#         return {'signature_image':context}