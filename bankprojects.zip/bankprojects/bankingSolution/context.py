import  datetime
from django.contrib.auth.models import User
from bankingSolution.models import SendMoney
from Bank_Admin_Portal.models import Users_Account
from forex_python.converter import CurrencyRates
def dates(request):
    all_users = Users_Account.objects.all()
    c = CurrencyRates()
    usa = c.get_rate('INR', 'USD')  
    uk = c.get_rate('INR', 'GBP') 
    japan = c.get_rate('INR', 'JPY')  
    china = c.get_rate('INR', 'CNY')
    if request.user.is_authenticated:
     	date = datetime.date.today()
     	moneyrecivedcount = SendMoney.objects.filter(account_number=request.user.username,date__icontains=date).all().count()
     	current_user = request.user
     	user_email = current_user.email
     	user_profile = Users_Account.objects.filter(email=user_email).all()
     	  
		    
    else:
    	user_profile = ""
    	moneyrecivedcount =""
    
    return {'user_profile':user_profile,'moneyrecivedcount':moneyrecivedcount,'all_users':all_users,'usa':usa,'uk':uk,'japan':japan,'china':china}
