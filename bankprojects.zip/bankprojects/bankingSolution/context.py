import  datetime
from django.contrib.auth.models import User
from bankingSolution.models import SendMoney
from Bank_Admin_Portal.models import Users_Account,SuperUserRegistration,Staff,Admin
from forex_python.converter import CurrencyRates


def context_data(request):
    staff = Staff.objects.all().count()
    admin = Admin.objects.all().count()
    staff_admin_count = int(staff) + int(admin)
    all_users = Users_Account.objects.all()
    c = CurrencyRates()
    usa = c.get_rate('INR', 'USD')  
    uk = c.get_rate('INR', 'GBP') 
    japan = c.get_rate('INR', 'JPY')  
    china = c.get_rate('INR', 'CNY')
    if request.user.is_authenticated:
        date = datetime.date.today()
        moneyrecivedcount = SendMoney.objects.filter(account_number=request.user.username,date__icontains=date).all().count()
        current_user = request.user
        user_email = current_user.email
        user_profile = Users_Account.objects.filter(email=user_email).all()
        admin_profile = SuperUserRegistration.objects.filter(email=user_email).all()
        p = Users_Account.objects.get(email=user_email)
        profile_pic = p.profile_pic
     	  
		    
    else:
        user_profile = ""
        moneyrecivedcount =""
        admin_profile=""
        profile_pic=""
    
    return {'user_profile':user_profile,'moneyrecivedcount':moneyrecivedcount,'all_users':all_users,'usa':usa,'uk':uk,'japan':japan,'china':china,'admin_profile':admin_profile,'staff_count':staff,'admin_count':admin,'staff_admin_count':staff_admin_count,'profile_pic':profile_pic}
