import  datetime
from django.contrib.auth.models import User
from bankingSolution.models import SendMoney
from Bank_Admin_Portal.models import Users_Account
def dates(request):
    date=datetime.datetime.now()
    date_without_time = datetime.date.today()
    current_user = request.user
    user_email = current_user.email
    user_profile = Users_Account.objects.filter(email=user_email).all()
    #user_profile = user_data.profile_pic
    
    
    # moneyrecivedcount = SendMoney.objects.filter(date__icontains=date_without_time).filter(account_number=User.username).all()
    return {'date':date,'date_without_time':date_without_time,'user_profile':user_profile}#,'moneyrecivedcount':moneyrecivedcount}
